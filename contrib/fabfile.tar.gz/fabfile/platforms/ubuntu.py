def post_install():
    """
    Post install operations on an Ubuntu system
    """    
    pass
